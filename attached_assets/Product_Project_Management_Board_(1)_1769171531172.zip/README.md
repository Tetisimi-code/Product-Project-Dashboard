
  # Product Project Management Board

  This is a code bundle for Product Project Management Board. The original project is available at https://www.figma.com/design/5rfdyAyJXHtGVZQnhNQPM1/Product-Project-Management-Board.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  